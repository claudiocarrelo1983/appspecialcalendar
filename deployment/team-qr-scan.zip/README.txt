Upload common and frontend into httpdocs, preserving paths.
Team scanning uses Members/List View and Members/Attendance View. Recording check-in requires Attendance Create; checkout requires Edit, deletion requires Delete.
The installed FTX and Demo apps already support the native camera when this server configuration is present. No new APK is required.
