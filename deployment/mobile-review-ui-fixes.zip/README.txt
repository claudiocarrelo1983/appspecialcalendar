Demo and FTX mobile review fixes — 2026-11-03

Ready workspace files: canonical menu titles; visible challenge/competition actions; weekday accessible labels; notification locale setup; payment PT/EN labels and wrapping; wrapping company settings links; no repeated mobile plan title; signed-in FAQ page route/heading.

Upload the frontend and common directories in this archive to the corresponding live website paths. No migration is required for these UI fixes. These files are already applied to C:\inetpub\wwwroot\workspace. Uploaded live changes affect the website pages embedded in both company apps.

The app change in src/utils/nativeAdminPages.js has also been synchronized to the Demo project: native form labels read aria-label and associated/wrapping labels. Installed apps need a compatible update for that change. No OTA update or cloud build has been published.

Verified locally: 240 tests; 70 company checks; 97 shared source/native files and dependencies identical; iOS and Android bundle exports; PHP syntax and PT/EN checks; 390px sample layout checks. Real signed-in phone verification is still needed, particularly original server permissions and payment actions. No Stripe transaction, live event creation, permission change or database migration was executed.

INDIVIDUAL TEAM PERMISSIONS ARE EXCLUDED. That proposal is inactive and requires explicit approval because it changes server authorization. Its files are outside application/autoload and migration directories in deployment/mobile-review-permissions-proposal. Do not deploy or execute the proposal as part of this archive.