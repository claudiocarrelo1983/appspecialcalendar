<?php

namespace frontend\controllers;

use common\models\Newsletter;
use yii\web\Controller;
use common\helpers\Helpers;

use common\models\LoginForm;
use common\models\TicketsSearch;
use common\models\Tickets;
use common\models\SendingLog;
use Yii;
use common\models\Events;
use common\helpers\PermissionsHelpers;
use yii\db\Query;

//Yii::$app->language = 'en-EN';

class FaqsAdminController extends Controller
{
    public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }

        // Authenticated help does not require an unrelated gym menu permission.
        return Helpers::adminBeforeAction($this, false, true);
    }

    
    public function actionIndex()
    {
         
        if (Yii::$app->user->isGuest) {
             return $this->redirect(['site/login' . \common\helpers\Helpers::getUserAgent()]);
        }

     
        $base_url = Helpers::getApplicationDomain();  
        
        switch($base_url){
            case 'localhost:86':    
            case 'teamtvde.pt':   
                   
                $template = '/faqs-tvde-admin/index';     
                break;

            case 'localhost:82':  
         
                $template = '/faqs-admin/index';      
                break;
        
            default:            
                $template = '/faqs-admin/index';      
                break;
        }  
   
        $query = new Query;

        $faqs = $query->select('*')->from(['faqs'])  
                       ->where([
                            'position' => 'backend',
                            'active' => '1'
                        ])    
                        ->orderBy(['order' => SORT_ASC])->all();
                        
        $model = new Tickets();
        
        if ($this->request->isPost && $model->load($this->request->post())) {

            $model->company_code = Yii::$app->user->identity->company_code;  
            $model->level = Yii::$app->user->identity->level;    
            $model->created_date = date('Y-m-d H:i');
            $model->ticket_number = 't'.Helpers::generateRandowHumber();

            if($model->validate()){
                
                $modelSendingLog = new SendingLog();
                $modelSendingLog::saveSendingLog('email', $model, $modelSendingLog, 'contact_form', true, [], Yii::$app->language);  
                $model->save();
            }
        }

        return $this->render($template, [
            'faqs' => $faqs,
            'model' => $model,
        ]);

    }

}
