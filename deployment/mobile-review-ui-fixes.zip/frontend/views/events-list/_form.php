<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\CompanyLocations;
use common\helpers\Helpers;

/** @var yii\web\View $this */
/** @var common\models\Events $model */
/** @var yii\widgets\ActiveForm $form */

$eventTypes = [
    'event' => Yii::t('app', 'event'),
    'class' => Yii::t('app', 'class'),
    'workshop' => Yii::t('app', 'workshop'),
];

$frequencies = [
    'one_time' => Yii::t('app', 'one_time'),
    'daily' => Yii::t('app', 'daily'),
    'weekly' => Yii::t('app', 'weekly'),
    'monthly' => Yii::t('app', 'monthly'),
];

$companyCode = $model->company_code ?: (Yii::$app->user->isGuest ? null : Yii::$app->user->identity->company_code);
$locationQuery = CompanyLocations::find()->where(['company_code' => $companyCode]);
Helpers::applyCurrentUserLocationScope($locationQuery);
$locationOptions = [];
foreach ($locationQuery->all() as $location) {
    $locationOptions[$location->location_code] = $location->displayName;
}
natcasesort($locationOptions);

$startDayValue = empty($model->start_day) ? '' : date('Y-m-d', strtotime($model->start_day));
$endDayValue = empty($model->end_day) ? '' : date('Y-m-d', strtotime($model->end_day));
$startHourValue = empty($model->start_hour) ? '' : date('H:i', strtotime($model->start_hour));
$endHourValue = empty($model->end_hour) ? '' : date('H:i', strtotime($model->end_hour));

?>

<div class="events-form">
    <?php $form = ActiveForm::begin(); ?>

    <?= Html::activeHiddenInput($model, 'username') ?>
    <?= Html::activeHiddenInput($model, 'company_code') ?>
    <?= Html::activeHiddenInput($model, 'event_code') ?>
    <?= Html::activeHiddenInput($model, 'template_code') ?>
    <?= Html::activeHiddenInput($model, 'page_code_title') ?>
    <?= Html::activeHiddenInput($model, 'page_code_text') ?>
    <?= Html::activeHiddenInput($model, 'path') ?>
    <?= Html::activeHiddenInput($model, 'image') ?>
    <?= Html::activeHiddenInput($model, 'title') ?>

    <div class="row g-4 align-items-start">
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-3 mb-4">
                        <div class="events-form-icon events-form-icon-blue">
                            <i class="bx bx-calendar-event"></i>
                        </div>
                        <div>
                            <h2 class="h4 fw-bold mb-1"><?= Html::encode(Yii::t('app', 'event_details')) ?></h2>
                            <div class="text-muted"><?= Html::encode(Yii::t('app', 'event_details_hint')) ?></div>
                        </div>
                    </div>

                    <div class="row g-4">
                        <div class="col-md-4">
                            <?= $form->field($model, 'event_type')->dropDownList($eventTypes, [
                                'class' => 'form-select form-select-lg rounded-4 events-preview-source',
                                'data-preview' => 'type',
                            ]) ?>
                        </div>

                        <div class="col-md-4">
                            <?= $form->field($model, 'frequency')->dropDownList($frequencies, [
                                'class' => 'form-select form-select-lg rounded-4 events-preview-source',
                                'data-preview' => 'frequency',
                            ]) ?>
                        </div>

                        <div class="col-md-4">
                            <?= $form->field($model, 'company_code_location')->dropDownList($locationOptions, [
                                'class' => 'form-select form-select-lg rounded-4 events-preview-source',
                                'data-preview' => 'location',
                                'prompt' => Yii::t('app', 'select_location'),
                            ]) ?>
                        </div>

                        <div class="col-md-6">
                            <?= $form->field($model, 'title_pt')->textInput([
                                'maxlength' => true,
                                'class' => 'form-control form-control-lg rounded-4 events-preview-source',
                                'data-preview' => 'title',
                                'placeholder' => Yii::t('app', 'title_pt'),
                            ]) ?>
                        </div>

                        <div class="col-md-6">
                            <?= $form->field($model, 'title_en')->textInput([
                                'maxlength' => true,
                                'class' => 'form-control form-control-lg rounded-4 events-preview-source',
                                'data-preview' => 'title_fallback',
                                'placeholder' => Yii::t('app', 'title_en'),
                            ]) ?>
                        </div>

                        <div class="col-md-6">
                            <?= $form->field($model, 'text_pt')->textarea([
                                'rows' => 4,
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'description',
                                'placeholder' => Yii::t('app', 'description_pt'),
                            ]) ?>
                        </div>

                        <div class="col-md-6">
                            <?= $form->field($model, 'text_en')->textarea([
                                'rows' => 4,
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'description_fallback',
                                'placeholder' => Yii::t('app', 'description_en'),
                            ]) ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center gap-3 mb-4">
                        <div class="events-form-icon events-form-icon-green">
                            <i class="bx bx-time-five"></i>
                        </div>
                        <div>
                            <h3 class="h5 fw-bold mb-1"><?= Html::encode(Yii::t('app', 'schedule_and_capacity')) ?></h3>
                            <div class="text-muted"><?= Html::encode(Yii::t('app', 'schedule_and_capacity_hint')) ?></div>
                        </div>
                    </div>

                    <div class="row g-4">
                        <div class="col-md-3">
                            <?= $form->field($model, 'start_day')->input('date', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'start_day',
                                'value' => $startDayValue,
                            ]) ?>
                        </div>

                        <div class="col-md-3">
                            <?= $form->field($model, 'end_day')->input('date', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'end_day',
                                'value' => $endDayValue,
                            ]) ?>
                        </div>

                        <div class="col-md-3">
                            <?= $form->field($model, 'start_hour')->input('time', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'start_hour',
                                'value' => $startHourValue,
                            ])->label(Yii::t('app', 'starting_time')) ?>
                        </div>

                        <div class="col-md-3">
                            <?= $form->field($model, 'end_hour')->input('time', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'end_hour',
                                'value' => $endHourValue,
                            ])->label(Yii::t('app', 'ending_time')) ?>
                        </div>

                        <div class="col-md-4">
                            <?= $form->field($model, 'number_or_hours')->input('number', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'duration',
                                'min' => 1,
                                'step' => 1,
                            ])->label(Yii::t('app', 'maximum_time_minutes')) ?>
                        </div>

                        <div class="col-md-4">
                            <?= $form->field($model, 'max_num_people')->input('number', [
                                'class' => 'form-control rounded-4 events-preview-source',
                                'data-preview' => 'capacity',
                                'min' => 1,
                                'step' => 1,
                            ])->label(Yii::t('app', 'maximum_number_of_people')) ?>
                        </div>

                        <div class="col-md-4">
                            <?= $form->field($model, 'cost')->input('number', [
                                'class' => 'form-control rounded-4',
                                'min' => 0,
                                'step' => 1,
                            ]) ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <h6 class="mb-3">
                        <?= Html::encode(Yii::t('app', 'available_days_of_week')) ?>
                    </h6>

                    <?= $form->field($model, 'availableWeekDaysArr')
                        ->checkboxList(
                            $model::weekDaysOptions(),
                            [
                                'class' => 'row',
                                'item' => function ($index, $label, $name, $checked, $value) {
                                    return '
                                        <div class="col-md-3 mb-2">
                                            <label class="form-check">
                                                <input
                                                    type="checkbox"
                                                    class="form-check-input"
                                                    aria-label="' . Html::encode($label) . '"
                                                    name="' . Html::encode($name) . '"
                                                    value="' . Html::encode($value) . '" ' . ($checked ? 'checked' : '') . '>
                                                <span class="form-check-label">' . Html::encode($label) . '</span>
                                            </label>
                                        </div>
                                    ';
                                },
                            ]
                        )
                        ->label(false); ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body p-4">
                    <div class="row g-4 align-items-end">
                        <div class="col-md-12">
                            <?= $form->field($model, 'url')->textInput([
                                'maxlength' => true,
                                'class' => 'form-control rounded-4',
                                'placeholder' => Yii::t('app', 'url'),
                            ]) ?>
                        </div>

                        <div class="col-md-3">
                            <div class="form-check form-switch pb-2">
                                <?= Html::activeCheckbox($model, 'login_required', [
                                    'class' => 'form-check-input',
                                    'labelOptions' => ['class' => 'form-check-label fw-semibold'],
                                ]) ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-check form-switch pb-2">
                                <?= Html::activeCheckbox($model, 'active', [
                                    'class' => 'form-check-input',
                                    'labelOptions' => ['class' => 'form-check-label fw-semibold'],
                                ]) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card border-0 shadow-sm rounded-4 events-preview-card">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <div class="fw-bold"><?= Html::encode(Yii::t('app', 'preview')) ?></div>
                        <span class="badge rounded-pill text-bg-light" data-events-preview="frequency">
                            <?= Html::encode($frequencies[$model->frequency] ?? $model->frequency) ?>
                        </span>
                    </div>

                    <div class="events-preview-type mb-3" data-events-preview="type">
                        <?= Html::encode($eventTypes[$model->event_type] ?? $model->event_type) ?>
                    </div>

                    <h3 class="h4 fw-bold mb-2" data-events-preview="title">
                        <?= Html::encode($model->title_pt ?: $model->title_en ?: Yii::t('app', 'untitled_event')) ?>
                    </h3>

                    <p class="text-muted" data-events-preview="description">
                        <?= Html::encode($model->text_pt ?: $model->text_en ?: Yii::t('app', 'event_details_hint')) ?>
                    </p>

                    <div class="events-preview-grid">
                        <div>
                            <i class="bx bx-calendar"></i>
                            <span data-events-preview="date_range">
                                <?= Html::encode(trim($startDayValue . ($endDayValue && $endDayValue !== $startDayValue ? ' - ' . $endDayValue : ''))) ?>
                            </span>
                        </div>
                        <div>
                            <i class="bx bx-time"></i>
                            <span data-events-preview="time_range">
                                <?= Html::encode(trim($startHourValue . ($endHourValue ? ' - ' . $endHourValue : ''))) ?>
                            </span>
                        </div>
                        <div>
                            <i class="bx bx-timer"></i>
                            <span><span data-events-preview="duration"><?= Html::encode((string) $model->number_or_hours) ?></span> min</span>
                        </div>
                        <div>
                            <i class="bx bx-group"></i>
                            <span><span data-events-preview="capacity"><?= Html::encode((string) $model->max_num_people) ?></span> <?= Html::encode(Yii::t('app', 'people')) ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center justify-content-end">
                        <?= Helpers::displayButtonsForm($model); ?> 
                    </div>   
                </div>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<style>
.events-form .events-form-icon {
    align-items: center;
    border-radius: 999px;
    display: flex;
    flex: 0 0 auto;
    font-size: 28px;
    height: 52px;
    justify-content: center;
    width: 52px;
}

.events-form .events-form-icon-blue {
    background: rgba(var(--sc-primary-rgb, 13, 110, 253), .12);
    color: var(--sc-primary, #0d6efd);
}

.events-form .events-form-icon-green {
    background: rgba(var(--sc-primary-rgb, 13, 110, 253), .12);
    color: var(--sc-primary, #0d6efd);
}

.events-form .events-preview-card {
    position: sticky;
    top: 1rem;
}

.events-form .events-preview-type {
    background: rgba(var(--sc-primary-rgb, 13, 110, 253), .12);
    border-radius: 999px;
    color: var(--sc-primary, #0d6efd);
    display: inline-flex;
    font-weight: 700;
    padding: .45rem .75rem;
}

.events-form .events-preview-grid {
    display: grid;
    gap: .75rem;
}

.events-form .events-preview-grid > div {
    align-items: center;
    background: #f8fafc;
    border-radius: 1rem;
    display: flex;
    gap: .65rem;
    padding: .8rem 1rem;
}

.events-form .events-preview-grid i {
    color: var(--sc-primary, #0d6efd);
    font-size: 1.25rem;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function(){
    const sources = document.querySelectorAll('.events-preview-source');
    const preview = function(name){
        return document.querySelector('[data-events-preview="' + name + '"]');
    };

    const valueText = function(selector){
        const element = document.querySelector(selector);
        if(!element){
            return '';
        }

        if(element.tagName === 'SELECT'){
            return element.options[element.selectedIndex] ? element.options[element.selectedIndex].text : '';
        }

        return element.value || '';
    };

    const updatePreview = function(){
        const title = valueText('[data-preview="title"]') || valueText('[data-preview="title_fallback"]') || <?= json_encode(Yii::t('app', 'untitled_event')) ?>;
        const description = valueText('[data-preview="description"]') || valueText('[data-preview="description_fallback"]') || <?= json_encode(Yii::t('app', 'event_details_hint')) ?>;
        const type = valueText('[data-preview="type"]');
        const frequency = valueText('[data-preview="frequency"]');
        const startDay = valueText('[data-preview="start_day"]');
        const endDay = valueText('[data-preview="end_day"]');
        const startHour = valueText('[data-preview="start_hour"]');
        const endHour = valueText('[data-preview="end_hour"]');
        const duration = valueText('[data-preview="duration"]');
        const capacity = valueText('[data-preview="capacity"]');

        if(preview('title')){
            preview('title').textContent = title;
        }

        if(preview('description')){
            preview('description').textContent = description;
        }

        if(preview('type')){
            preview('type').textContent = type;
        }

        if(preview('frequency')){
            preview('frequency').textContent = frequency;
        }

        if(preview('date_range')){
            preview('date_range').textContent = startDay + (endDay && endDay !== startDay ? ' - ' + endDay : '');
        }

        if(preview('time_range')){
            preview('time_range').textContent = startHour + (endHour ? ' - ' + endHour : '');
        }

        if(preview('duration')){
            preview('duration').textContent = duration;
        }

        if(preview('capacity')){
            preview('capacity').textContent = capacity;
        }
    };

    sources.forEach(function(source){
        source.addEventListener('input', updatePreview);
        source.addEventListener('change', updatePreview);
    });

    updatePreview();
});
</script>
