<?php

use common\helpers\Helpers;
use common\models\GymClassStripePayment;
use common\models\GymStripePaymentSettings;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var common\models\GymStripePaymentSettings $stripePaymentSettings */
/** @var common\models\GymClassStripePayment[] $stripePayments */
/** @var array $stripePaymentClassOptions */
/** @var string $stripeWebhookUrl */
/** @var string|null $stripeConnectionError */
/** @var common\models\GymStripeWebhookEvent|null $latestWebhookEvent */
/** @var string $activeTab */
/** @var string $brandColor */
/** @var string $brandColorRgb */

$this->title = Yii::t('app', 'payments_setup');
$stripeCurrentMode = $stripePaymentSettings->mode ?: GymStripePaymentSettings::MODE_TEST;
$stripeCanAccept = $stripePaymentSettings->canAcceptPayments();
$stripeTransferStatus = $stripePaymentSettings->recipientTransferStatus($stripeCurrentMode);
$stripeRequirementsDue = $stripePaymentSettings->currentlyDueRequirements($stripeCurrentMode);
$stripeDisabledReason = $stripePaymentSettings->accountDisabledReason($stripeCurrentMode);
$stripeHasCurrentWebhookSecret = $stripePaymentSettings->hasSavedWebhookSecret($stripeCurrentMode);
$stripeHasCurrentApiKey = $stripePaymentSettings->hasPlatformCredentials($stripeCurrentMode);
$stripeConnectActionLabel = $stripePaymentSettings->isConnected() ? 'Atualizar conta Stripe' : 'Ligar conta Stripe';
$paymentLabels = require Yii::getAlias('@common/messages/' . (strpos(strtolower(Yii::$app->language),'pt')===0?'pt':'en') . '/mobile-review.php');
$paymentT = static function ($key, $fallback) use ($paymentLabels) {
    if(isset($paymentLabels[$key]))return $paymentLabels[$key];
    $text = Yii::t('app', $key);
    return $text === $key ? $fallback : $text;
};
$configurationActive = $activeTab !== 'management';
$managementActive = $activeTab === 'management';
$refreshErrorMessage = json_encode($paymentT('error', 'Erro'), JSON_UNESCAPED_UNICODE);
$brandColor = $brandColor ?? '#0d6efd';
$brandColorRgb = $brandColorRgb ?? '13, 110, 253';
$customerFilterGuid = Yii::$app->request->get('stripe_customer_guid');
$customerFilterText = Yii::$app->request->get('stripe_customer');
?>


<div class="payments-setup-page" style="--payments-brand: <?= Html::encode($brandColor) ?>; --payments-brand-rgb: <?= Html::encode($brandColorRgb) ?>;">
    <?php foreach (['success' => 'success', 'danger' => 'danger', 'warning' => 'warning', 'info' => 'info'] as $flash => $class): ?>
        <?php if (Yii::$app->session->hasFlash($flash)): ?>
            <div class="alert alert-<?= Html::encode($class) ?> alert-dismissible fade show rounded-4 shadow-sm mb-4" role="alert">
                <?= Yii::$app->session->getFlash($flash) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="<?= Html::encode(Yii::t('app', 'close')) ?>"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <div class="gym-menu-page-header payments-setup-head">
        <?= \common\widgets\GymPageHeading::widget(['title' => 'payments_setup', 'description' => 'stripe_checkout_company_hint', 'icon' => 'bx bx-credit-card']) ?>
        <span class="payments-setup-status <?= $stripeCanAccept ? 'is-ready' : 'is-pending' ?>">
            <i class="bx <?= $stripeCanAccept ? 'bx-check-circle' : 'bx-time-five' ?>"></i>
            <?= Html::encode($paymentT($stripeCanAccept ? 'integration_ready' : 'not_configured', $stripeCanAccept ? 'Integração pronta' : 'Não configurado')) ?>
        </span>
    </div>

    <section class="card border-0 rounded-4 shadow-sm payments-setup-card">
        <div class="card-body">
            <ul class="nav nav-pills payments-setup-tabs mb-4" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link btn mr-2 rounded-4 js-payments-setup-tab <?= $configurationActive ? 'active btn-primary-modern' : 'btn-reset-modern' ?>" data-bs-toggle="pill" data-bs-target="#stripeConfiguration" type="button" role="tab">
                        <i class="bx bx-cog"></i><span><?= Html::encode($paymentT('configuration', 'Configuração')) ?></span>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link btn mr-2 rounded-4 js-payments-setup-tab <?= $managementActive ? 'active btn-primary-modern' : 'btn-reset-modern' ?>" data-bs-toggle="pill" data-bs-target="#stripeManagement" type="button" role="tab">
                        <i class="bx bx-list-check"></i><span><?= Html::encode($paymentT('management', 'Gestão')) ?></span>
                    </button>
                </li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade <?= $configurationActive ? 'show active' : '' ?>" id="stripeConfiguration" role="tabpanel">
                    <div class="payments-setup-guide rounded-4 mb-4">
                        <div class="payments-setup-guide-head">
                            <span class="payments-card-icon"><i class="bx bx-info-circle"></i></span>
                            <div>
                                <div class="fw-bold"><?= Html::encode($paymentT('how_to_setup_payments', 'Como configurar os pagamentos')) ?></div>
                                <div class="text-muted small"><?= Html::encode($paymentT('payments_setup_intro', 'Use estes passos para ligar o Stripe Checkout às reservas pagas das aulas.')) ?></div>
                            </div>
                        </div>
                        <div class="payments-setup-steps">
                            <div class="payments-setup-step">
                                <strong>1</strong>
                                <div>
                                    <div class="fw-semibold"><?= Html::encode($paymentT('create_or_open_stripe_account', 'Criar ou abrir a conta Stripe')) ?></div>
                                    <p><?= Html::encode($paymentT('create_or_open_stripe_account_hint', 'Entre no Stripe Dashboard da empresa e confirme que a conta está validada para receber pagamentos e transferências.')) ?></p>
                                </div>
                            </div>
                            <div class="payments-setup-step">
                                <strong>2</strong>
                                <div>
                                    <div class="fw-semibold"><?= Html::encode($paymentT('copy_stripe_secret_key', 'Copiar a chave secreta')) ?></div>
                                    <p><?= Html::encode($paymentT('copy_stripe_secret_key_hint', 'Em Developers > API keys, copie a chave secreta do ambiente correto e cole-a no campo Sandbox ou Produção nesta página.')) ?></p>
                                </div>
                            </div>
                            <div class="payments-setup-step">
                                <strong>3</strong>
                                <div>
                                    <div class="fw-semibold"><?= Html::encode($paymentT('configure_stripe_webhook', 'Configurar o webhook')) ?></div>
                                    <p><?= Html::encode($paymentT('configure_stripe_webhook_hint', 'Em Developers > Webhooks, adicione o endpoint abaixo e selecione estes eventos:')) ?></p>
                                    <code class="payments-setup-webhook d-block text-truncate"><?= Html::encode($stripeWebhookUrl) ?></code>
                                    <p><?= Html::encode($paymentT('localhost_stripe_cli_hint', 'Em localhost, use o Stripe CLI para reenviar eventos para este endpoint local.')) ?></p>
                                    <div class="payments-setup-events">
                                        <span>checkout.session.completed</span>
                                        <span>checkout.session.expired</span>
                                        <span>payment_intent.succeeded</span>
                                        <span>payment_intent.payment_failed</span>
                                        <span>payment_intent.canceled</span>
                                        <span>account.updated</span>
                                        <span>v2.core.account.updated</span>
                                    </div>
                                </div>
                            </div>
                            <div class="payments-setup-step">
                                <strong>4</strong>
                                <div>
                                    <div class="fw-semibold"><?= Html::encode($paymentT('enable_and_test_payments', 'Ativar e testar')) ?></div>
                                    <p><?= Html::encode($paymentT('enable_and_test_payments_hint', 'Guarde esta configuração em /payments-setup/index, ligue a conta Stripe e faça uma reserva de teste antes de mudar para Produção.')) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php $form = ActiveForm::begin([
                        'action' => Url::to(['/payments-setup/index']),
                        'options' => ['class' => 'payments-setup-form'],
                    ]); ?>
                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <?= $form->field($stripePaymentSettings, 'enabled')->dropDownList([
                                1 => $paymentT('active', 'Ativo'),
                                0 => $paymentT('inactive', 'Inativo'),
                            ], ['class' => 'form-select rounded-4'])->label($paymentT('stripe_checkout_enabled', 'Stripe Checkout ativo')) ?>
                        </div>
                        <div class="col-12 col-md-4">
                            <?= $form->field($stripePaymentSettings, 'mode')->dropDownList([
                                GymStripePaymentSettings::MODE_TEST => $paymentT('sandbox', 'Sandbox'),
                                GymStripePaymentSettings::MODE_LIVE => $paymentT('production', 'Produção'),
                            ], ['class' => 'form-select rounded-4'])->label($paymentT('stripe_environment', 'Ambiente Stripe')) ?>
                        </div>
                        <div class="col-12 col-md-4">
                            <?= $form->field($stripePaymentSettings, 'platform_commission_bps')->input('number', [
                                'class' => 'form-control rounded-4',
                                'min' => 0,
                                'step' => 1,
                            ])->label($paymentT('platform_commission_bps', 'Comissão da plataforma (bps)')) ?>
                        </div>
                        <div class="col-12 col-md-6">
                            <?= $form->field($stripePaymentSettings, 'test_secret_key')->passwordInput([
                                'class' => 'form-control rounded-4',
                                'autocomplete' => 'new-password',
                                'placeholder' => $stripePaymentSettings->maskedSecretKey(GymStripePaymentSettings::MODE_TEST),
                            ])->label($paymentT('stripe_test_secret_key', 'Chave secreta Stripe sandbox')) ?>
                            <div class="form-text">
                                <?= Html::encode($paymentT('secret_key_leave_blank', 'Deixe em branco para manter a chave guardada.')) ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <?= $form->field($stripePaymentSettings, 'live_secret_key')->passwordInput([
                                'class' => 'form-control rounded-4',
                                'autocomplete' => 'new-password',
                                'placeholder' => $stripePaymentSettings->maskedSecretKey(GymStripePaymentSettings::MODE_LIVE),
                            ])->label($paymentT('stripe_live_secret_key', 'Chave secreta Stripe produção')) ?>
                            <div class="form-text">
                                <?= Html::encode($paymentT('secret_key_leave_blank', 'Deixe em branco para manter a chave guardada.')) ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <?= $form->field($stripePaymentSettings, 'test_webhook_secret')->passwordInput([
                                'class' => 'form-control rounded-4',
                                'autocomplete' => 'new-password',
                                'placeholder' => $stripePaymentSettings->maskedWebhookSecret(GymStripePaymentSettings::MODE_TEST),
                            ])->label($paymentT('stripe_test_webhook_secret', 'Webhook signing secret sandbox')) ?>
                            <div class="form-text">
                                <?= Html::encode($paymentT('webhook_secret_leave_blank', 'Deixe em branco para manter o signing secret guardado. Deve começar por whsec_.')) ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <?= $form->field($stripePaymentSettings, 'live_webhook_secret')->passwordInput([
                                'class' => 'form-control rounded-4',
                                'autocomplete' => 'new-password',
                                'placeholder' => $stripePaymentSettings->maskedWebhookSecret(GymStripePaymentSettings::MODE_LIVE),
                            ])->label($paymentT('stripe_live_webhook_secret', 'Webhook signing secret produção')) ?>
                            <div class="form-text">
                                <?= Html::encode($paymentT('webhook_secret_leave_blank', 'Deixe em branco para manter o signing secret guardado. Deve começar por whsec_.')) ?>
                            </div>
                        </div>
                        <div class="col-12 col-xl-6">
                            <div class="payments-connect-card rounded-4">
                                <span class="payments-card-icon"><i class="bx bxl-stripe"></i></span>
                                <div>
                                    <div class="text-muted small fw-bold text-uppercase"><?= Html::encode($paymentT('stripe_connected_account', 'Conta Stripe ligada')) ?></div>
                                    <div class="fw-bold"><?= Html::encode($stripePaymentSettings->maskedAccountId()) ?></div>
                                    <div class="small text-muted">
                                        <?= Html::encode($paymentT('recipient_transfers_status', 'Transferências para o ginásio')) ?>:
                                        <?= Html::encode($stripeTransferStatus ?: $paymentT('not_configured', 'Não configurado')) ?>
                                        ·
                                        <?= Html::encode($paymentT('account_requirements_due', 'Requisitos pendentes')) ?>:
                                        <?= Html::encode((string)count($stripeRequirementsDue)) ?>
                                    </div>
                                    <?php if (!empty($stripeConnectionError)): ?>
                                        <div class="small text-danger mt-1"><?= Html::encode($stripeConnectionError) ?></div>
                                    <?php elseif (!empty($stripeDisabledReason)): ?>
                                        <div class="small text-warning mt-1"><?= Html::encode($stripeDisabledReason) ?></div>
                                    <?php elseif (!empty($stripeRequirementsDue)): ?>
                                        <div class="small text-warning mt-1"><?= Html::encode(implode(', ', $stripeRequirementsDue)) ?></div>
                                    <?php elseif (!$stripePaymentSettings->isConnected() && $stripeHasCurrentApiKey): ?>
                                        <div class="small text-warning mt-1"><?= Html::encode($paymentT('stripe_account_not_connected_hint', 'A chave API está guardada, mas a conta Stripe ainda não foi ligada. Use o botão para abrir o onboarding Stripe.')) ?></div>
                                    <?php endif; ?>
                                </div>
                                <?= Html::submitButton('<i class="bx bx-link-external"></i><span>' . Html::encode($paymentT($stripePaymentSettings->isConnected()?'update_stripe_account':'connect_stripe_account', $stripeConnectActionLabel)) . '</span>', [
                                    'class' => 'btn btn-primary-modern rounded-4 d-inline-flex align-items-center justify-content-center gap-2 ms-auto',
                                    'formaction' => Url::to(['/payments-setup/stripe-connect']),
                                    'formmethod' => 'post',
                                ]) ?>
                            </div>
                        </div>
                        <div class="col-12 col-xl-6">
                            <div class="payments-connect-card rounded-4">
                                <span class="payments-card-icon"><i class="bx bx-link"></i></span>
                                <div class="min-w-0">
                                    <div class="text-muted small fw-bold text-uppercase"><?= Html::encode($paymentT('webhook_url', 'URL do webhook')) ?></div>
                                    <code class="d-block text-truncate"><?= Html::encode($stripeWebhookUrl) ?></code>
                                    <div class="small <?= $stripeHasCurrentWebhookSecret ? 'text-success' : 'text-warning' ?>">
                                        <?= Html::encode($paymentT($stripeHasCurrentWebhookSecret ? 'webhook_secret_configured' : 'webhook_secret_not_configured', $stripeHasCurrentWebhookSecret ? 'Webhook secret configurado' : 'Webhook secret não configurado')) ?>
                                    </div>
                                    <div class="small text-muted">
                                        <?= Html::encode($paymentT('webhook_delivery_status', 'Entrega do webhook')) ?>:
                                        <?= Html::encode($latestWebhookEvent ? (($latestWebhookEvent->event_type ?: '-') . ' · ' . ($latestWebhookEvent->processed_at ?: '-')) : $paymentT('no_webhook_delivery_yet', 'Ainda sem entregas recebidas')) ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="payments-fees-card rounded-4">
                                <span class="payments-card-icon"><i class="bx bx-receipt"></i></span>
                                <div class="min-w-0">
                                    <div class="fw-bold mb-1"><?= Html::encode($paymentT('stripe_fees', 'Taxas Stripe')) ?></div>
                                    <div class="text-muted"><?= Html::encode($paymentT('stripe_fees_portugal_notice', 'Exemplo oficial Stripe Portugal/EEE: cartões standard EEE 1,5% + €0,25. A taxa final pode variar por método, cartão e conta.')) ?></div>
                                </div>
                                <a href="<?= Html::encode(Url::to(['/payments-setup/index'])) ?>"><?= Html::encode($paymentT('stripe_pricing', 'Preços Stripe')) ?></a>
                                <span class="mx-1">·</span>
                                <a href="<?= Html::encode(Url::to(['/payments-setup/index'])) ?>"><?= Html::encode($paymentT('configure_individual_class_prices', 'Configurar preços das aulas')) ?></a>
                            </div>
                        </div>
                        <div class="col-12 d-flex justify-content-end">
                            <?= Html::submitButton('<i class="bx bx-save"></i>' . Yii::t('app', 'save_button'), [
                                'class' => 'btn btn-primary-modern mr-2 rounded-4 btn-sm payments-save-btn',
                            ]) ?>
                        </div>
                    </div>
                    <?php ActiveForm::end(); ?>
                </div>

                <div class="tab-pane fade <?= $managementActive ? 'show active' : '' ?>" id="stripeManagement" role="tabpanel">
                    <?= Html::beginForm(['/payments-setup/index'], 'get', ['class' => 'row g-2 mb-3 payments-filter-form']) ?>
                    <?= Html::hiddenInput('tab', 'management') ?>
                    <div class="col-12 col-md-2"><?= Html::input('date', 'stripe_from', Yii::$app->request->get('stripe_from'), ['class' => 'form-control rounded-4']) ?></div>
                    <div class="col-12 col-md-2"><?= Html::input('date', 'stripe_to', Yii::$app->request->get('stripe_to'), ['class' => 'form-control rounded-4']) ?></div>
                    <div class="col-12 col-md-2"><?= Html::dropDownList('stripe_class', Yii::$app->request->get('stripe_class'), ['' => Yii::t('app', 'classes')] + $stripePaymentClassOptions, ['class' => 'form-select rounded-4']) ?></div>
                    <div class="col-12 col-md-2 payments-autocomplete-wrap">
                        <?= Html::hiddenInput('stripe_customer_guid', $customerFilterGuid, ['class' => 'js-stripe-customer-guid']) ?>
                        <?= Html::textInput('stripe_customer', $customerFilterText, [
                            'class' => 'form-control rounded-4 js-stripe-customer-autocomplete',
                            'placeholder' => Yii::t('app', 'customer'),
                            'autocomplete' => 'off',
                            'data-url' => Url::to(['/payments-setup/client-autocomplete']),
                        ]) ?>
                        <div class="payments-autocomplete-list rounded-4 shadow-sm d-none js-stripe-customer-results"></div>
                    </div>
                    <div class="col-12 col-md-2"><?= Html::dropDownList('stripe_status', Yii::$app->request->get('stripe_status'), ['' => Yii::t('app', 'status')] + GymClassStripePayment::paymentStatusOptions(), ['class' => 'form-select rounded-4']) ?></div>
                    <div class="col-12 col-md-2">
                        <?= Html::submitButton('<i class="bx bx-filter"></i><span>' . Html::encode(Yii::t('app', 'filter')) . '</span>', ['class' => 'btn btn-primary-modern mr-2 rounded-4 w-100']) ?>
                    </div>
                    <?= Html::endForm() ?>

                    <div class="table-responsive payments-table-wrap">
                        <table class="table align-middle mb-0">
                            <thead>
                                <tr>
                                    <th><?= Html::encode(Yii::t('app', 'customer')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'class')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'amount')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'payment_status')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'booking_status')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'merchant_reference')) ?></th>
                                    <th><?= Html::encode(Yii::t('app', 'created_date')) ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stripePayments as $payment): ?>
                                    <tr>
                                        <td><?= Html::encode($payment->client->full_name ?? $payment->client_guid) ?></td>
                                        <td><?= Html::encode($payment->gymClass->name ?? $payment->class_code) ?><div class="text-muted small"><?= Html::encode(date('d/m/Y H:i', strtotime($payment->start_datetime))) ?></div></td>
                                        <td><?= Html::encode(Yii::$app->formatter->asCurrency($payment->amount(), $payment->currency)) ?></td>
                                        <td><?= $payment->statusBadge() ?></td>
                                        <td><span class="badge rounded-pill text-bg-light"><?= Html::encode(Yii::t('app', $payment->booking_status)) ?></span></td>
                                        <td><code><?= Html::encode($payment->merchant_reference ?: $payment->code) ?></code><div class="text-muted small text-truncate"><?= Html::encode($payment->stripe_payment_intent_id ?: $payment->stripe_checkout_session_id) ?></div></td>
                                        <td><?= Html::encode($payment->created_date) ?></td>
                                        <td>
                                            <?= Html::button('<i class="bx bx-refresh"></i>', [
                                                'class' => 'btn btn-primary-modern mr-2 btn-sm rounded-4 js-refresh-stripe-payment',
                                                'data-url' => Url::to(['/payments-setup/refresh-stripe-payment', 'payment_code' => $payment->code]),
                                                'title' => Yii::t('app', 'refresh'),
                                            ]) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($stripePayments)): ?>
                                    <tr><td colspan="8" class="text-muted py-4 text-center"><?= Html::encode(Yii::t('app', 'no_data_found')) ?></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
    .payments-setup-page { color: #111827; }
    .payments-setup-card .card-body { padding: 1.35rem; }
    .payments-setup-head {
        align-items: flex-start;
        display: flex;
        gap: 1rem;
        justify-content: space-between;
        margin-bottom: 1.1rem;
    }
    .payments-setup-title {
        align-items: flex-start;
        display: flex;
        gap: .85rem;
    }
    .payments-setup-title > i {
        align-items: center;
        background: rgba(var(--payments-brand-rgb), .1);
        border-radius: 14px;
        color: var(--payments-brand);
        display: inline-flex;
        flex: 0 0 auto;
        font-size: 1.3rem;
        height: 42px;
        justify-content: center;
        width: 42px;
    }
    .payments-setup-title h1 {
        font-size: 1.15rem;
        font-weight: 850;
        margin: .15rem 0 0;
    }
    .payments-setup-title p {
        color: #64748b;
        font-size: .86rem;
        font-weight: 600;
        margin: .15rem 0 0;
    }
    .payments-setup-status {
        align-items: center;
        border-radius: 999px;
        display: inline-flex;
        font-size: .78rem;
        font-weight: 850;
        gap: .35rem;
        min-height: 34px;
        padding: .42rem .75rem;
        white-space: nowrap;
    }
    .payments-setup-status.is-ready { background: rgba(22,163,74,.1); color: #15803d; }
    .payments-setup-status.is-pending { background: rgba(245,158,11,.12); color: #b45309; }
    .payments-setup-tabs {
        background: #f8fafc;
        border: 1px solid rgba(148,163,184,.18);
        border-radius: 1rem;
        display: inline-flex;
        gap: .45rem;
        padding: .35rem;
    }
    .payments-setup-tabs .nav-link {
        align-items: center;
        border: 0;
        color: #475569;
        display: inline-flex;
        font-weight: 850;
        gap: .4rem;
        min-height: 40px;
        padding: .5rem .85rem;
    }
    .payments-setup-tabs .nav-link:hover,
    .payments-setup-tabs .nav-link:focus {
        background: rgba(var(--payments-brand-rgb), .1);
        color: var(--payments-brand);
    }
    .payments-setup-tabs .nav-link.active {
        background: var(--payments-brand) !important;
        box-shadow: 0 10px 22px rgba(var(--payments-brand-rgb), .18);
        color: #fff !important;
    }
    .payments-setup-tabs .nav-link.active:hover,
    .payments-setup-tabs .nav-link.active:focus {
        background: var(--payments-brand) !important;
        color: #fff !important;
    }
    .payments-setup-tabs .nav-link.active i,
    .payments-setup-tabs .nav-link.active span {
        color: #fff !important;
        opacity: 1 !important;
        visibility: visible !important;
    }
    .payments-setup-guide {
        background: linear-gradient(135deg, rgba(var(--payments-brand-rgb), .08), rgba(248,250,252,.96));
        border: 1px solid rgba(var(--payments-brand-rgb), .16);
        padding: 1rem;
    }
    .payments-setup-guide-head {
        align-items: center;
        display: flex;
        gap: .85rem;
        margin-bottom: .9rem;
    }
    .payments-setup-steps {
        display: grid;
        gap: .75rem;
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .payments-setup-step {
        align-items: flex-start;
        background: rgba(255,255,255,.78);
        border: 1px solid rgba(148,163,184,.18);
        border-radius: 1rem;
        display: flex;
        gap: .75rem;
        padding: .85rem;
    }
    .payments-setup-step > strong {
        align-items: center;
        background: var(--payments-brand);
        border-radius: 999px;
        color: #fff;
        display: inline-flex;
        flex: 0 0 auto;
        font-size: .85rem;
        height: 28px;
        justify-content: center;
        width: 28px;
    }
    .payments-setup-step p {
        color: #64748b;
        font-size: .82rem;
        font-weight: 600;
        margin: .15rem 0 0;
    }
    .payments-setup-webhook {
        background: #0f172a;
        border-radius: .65rem;
        color: #e2e8f0;
        margin-top: .45rem;
        max-width: 100%;
        padding: .45rem .6rem;
    }
    .payments-setup-events {
        display: flex;
        flex-wrap: wrap;
        gap: .35rem;
        margin-top: .5rem;
    }
    .payments-setup-events span {
        background: rgba(15,23,42,.06);
        border-radius: 999px;
        color: #334155;
        font-size: .72rem;
        font-weight: 750;
        padding: .25rem .5rem;
    }
    .payments-connect-card {
        align-items: center;
        background: #f8fafc;
        border: 1px solid rgba(148,163,184,.22);
        display: flex;
        gap: 1rem;
        justify-content: flex-start;
        min-height: 104px;
        padding: 1rem;
    }
    .payments-card-icon {
        align-items: center;
        background: rgba(var(--payments-brand-rgb), .1);
        border-radius: 16px;
        color: var(--payments-brand);
        display: inline-flex;
        flex: 0 0 auto;
        font-size: 1.25rem;
        height: 42px;
        justify-content: center;
        width: 42px;
    }
    .payments-connect-card .btn {
        margin-left: auto;
        white-space: nowrap;
    }
    .payments-fees-card {
        align-items: center;
        background: rgba(var(--payments-brand-rgb), .08);
        border: 1px solid rgba(var(--payments-brand-rgb), .18);
        color: #111827;
        display: grid;
        gap: .8rem;
        grid-template-columns: auto minmax(0, 1fr) auto auto auto;
        padding: 1rem;
    }
    .payments-fees-card a {
        color: var(--payments-brand);
        font-weight: 850;
        text-decoration: none;
    }
    .payments-save-btn {
        align-items: center;
        display: inline-flex;
        gap: .35rem;
    }
    .payments-table-wrap {
        border-top: 1px solid #e5e7eb;
    }
    .payments-autocomplete-wrap {
        position: relative;
    }
    .payments-autocomplete-list {
        background: #fff;
        border: 1px solid rgba(148,163,184,.28);
        left: 0;
        max-height: 240px;
        overflow-y: auto;
        position: absolute;
        right: 0;
        top: calc(100% + .35rem);
        z-index: 1050;
    }
    .payments-autocomplete-option {
        background: transparent;
        border: 0;
        color: #111827;
        display: flex;
        flex-direction: column;
        gap: .1rem;
        padding: .65rem .8rem;
        text-align: left;
        width: 100%;
    }
    .payments-autocomplete-option:hover,
    .payments-autocomplete-option:focus {
        background: rgba(var(--payments-brand-rgb), .08);
        color: var(--payments-brand);
        outline: none;
    }
    .payments-autocomplete-option span {
        font-weight: 800;
    }
    .payments-autocomplete-option small {
        color: #64748b;
        font-size: .76rem;
    }
    @media (max-width: 767.98px) {
        .payments-setup-head,
        .payments-connect-card {
            align-items: stretch;
            flex-direction: column;
        }
        .payments-setup-status,
        .payments-connect-card .btn {
            justify-content: center;
            width: 100%;
        }
        .payments-setup-tabs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            width: 100%;
        }
        .payments-setup-tabs .nav-link {
            justify-content: center;
            width: 100%;
        }
        .payments-setup-steps {
            grid-template-columns: 1fr;
        }
        .payments-fees-card {
            grid-template-columns: auto minmax(0, 1fr);
        }
        .payments-fees-card a,
        .payments-fees-card .mx-1 {
            grid-column: 1 / -1;
        }
    }
</style>

<?php
$this->registerJs(<<<JS
(function ($) {
    function syncPaymentTabs(activeTab) {
        $('.js-payments-setup-tab')
            .removeClass('btn-primary-modern')
            .addClass('btn-reset-modern');

        $(activeTab)
            .removeClass('btn-reset-modern')
            .addClass('btn-primary-modern');
    }

    syncPaymentTabs($('.js-payments-setup-tab.active').first());

    $('.js-payments-setup-tab').on('shown.bs.tab click', function () {
        syncPaymentTabs(this);
    });

    var customerRequest = null;
    var customerTimer = null;

    function escapeHtml(value) {
        return $('<div>').text(value || '').html();
    }

    function hideCustomerResults() {
        $('.js-stripe-customer-results').addClass('d-none').empty();
    }

    function renderCustomerResults(input, items) {
        var results = input.siblings('.js-stripe-customer-results');
        results.empty();

        if (!items || !items.length) {
            hideCustomerResults();
            return;
        }

        items.forEach(function (item) {
            var detail = item.detail ? '<small>' + escapeHtml(item.detail) + '</small>' : '';
            $('<button type="button" class="payments-autocomplete-option"></button>')
                .attr('data-id', item.id)
                .attr('data-value', item.value)
                .html('<span>' + escapeHtml(item.label) + '</span>' + detail)
                .appendTo(results);
        });

        results.removeClass('d-none');
    }

    $('.js-stripe-customer-autocomplete').on('input', function () {
        var input = $(this);
        input.siblings('.js-stripe-customer-guid').val('');
        loadCustomerResults(input);
    });

    $('.js-stripe-customer-autocomplete').on('focus', function () {
        loadCustomerResults($(this));
    });

    function loadCustomerResults(input) {
        var term = $.trim(input.val());
        window.clearTimeout(customerTimer);

        if (term.length < 2) {
            hideCustomerResults();
            return;
        }

        customerTimer = window.setTimeout(function () {
            if (customerRequest) {
                customerRequest.abort();
            }

            customerRequest = $.getJSON(input.data('url'), { q: term })
                .done(function (items) {
                    renderCustomerResults(input, items);
                });
        }, 180);
    }

    $(document).on('mousedown', '.payments-autocomplete-option', function (event) {
        event.preventDefault();
        var option = $(this);
        var wrap = option.closest('.payments-autocomplete-wrap');
        wrap.find('.js-stripe-customer-guid').val(option.data('id'));
        wrap.find('.js-stripe-customer-autocomplete').val(option.data('value'));
        hideCustomerResults();
    });

    $(document).on('mousedown', function (event) {
        if (!$(event.target).closest('.payments-autocomplete-wrap').length) {
            hideCustomerResults();
        }
    });

    $('.js-refresh-stripe-payment').on('click', function () {
        var button = $(this);
        var originalHtml = button.html();
        button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');
        $.post(button.data('url')).done(function (response) {
            if (response && response.message) {
                window.alert(response.message);
            }
            window.location.reload();
        }).fail(function (xhr) {
            var message = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : {$refreshErrorMessage};
            window.alert(message);
        }).always(function () {
            button.prop('disabled', false).html(originalHtml);
        });
    });
})(jQuery);
JS
);
?>
