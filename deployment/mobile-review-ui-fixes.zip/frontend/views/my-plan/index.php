<?php

use common\helpers\Helpers;
use common\helpers\MyPlanPricingHelper;
use yii\helpers\Html;
use yii\helpers\Url;

/** @var yii\web\View $this */
/** @var array $arrProgressbars */
/** @var array $arrCompanyPlan */
/** @var array $arrPricing */
/** @var float|int|string $professionalsPrice */
/** @var float|int|string $locationsPrice */
/** @var string $locations */
/** @var string $professionals */
/** @var string $selectedCategory */
/** @var array $pricingCategoriesVisibility */

$this->title = Yii::t('app', 'my_plan');
$typeArr = ['1_month', '12_month'];
$pricingCategoriesVisibility = $pricingCategoriesVisibility ?? [
    'bookings' => true,
    'classes-spaces' => true,
    'hotel-housekeeping' => true,
];
$selectedCategory = $selectedCategory ?? 'classes-spaces';
$currentLanguage = substr((string) Yii::$app->language, 0, 2);

$pricingText = [
    'pt' => [
        'category_eyebrow' => 'Escolha a area do negocio',
        'category_title' => 'Planos por tipo de operacao',
        'category_intro' => 'Veja o plano certo para a area ativa do seu negocio.',
        'bookings_title' => 'Bookings',
        'bookings_desc' => 'Para negocios que gerem marcacoes, clientes e profissionais.',
        'bookings_examples' => 'Saloes, clinicas, terapeutas e outros servicos por marcacao.',
        'classes_title' => 'Classes e Espacos',
        'classes_desc' => 'Para estudios, ginasios e academias que gerem aulas, membros e instrutores.',
        'classes_examples' => 'Pilates, yoga, CrossFit, artes marciais, danca, natacao, padel e fitness.',
        'hotel_title' => 'Hotel Housekeeping',
        'hotel_desc' => 'Para alojamentos que gerem quartos, equipas e operacoes de housekeeping.',
        'hotel_examples' => 'Hoteis, hostels, resorts e guest houses.',
        'billing' => 'Faturacao',
        'monthly' => 'Mensal',
        'annual' => 'Anual',
        'save_10' => 'Poupe 10%',
        'per_month_short' => '/ mes',
        'per_year_short' => '/ ano',
        'classes_plan_name' => 'Classes e Espacos',
        'classes_plan_desc' => 'Um plano unico para gerir aulas, membros, instrutores e espacos com clareza.',
        'classes_feature_1' => 'Gestao de aulas e horarios',
        'classes_feature_1_desc' => 'Crie aulas, categorias e horarios recorrentes para organizar a agenda.',
        'classes_feature_2' => 'Membros, instrutores e presencas',
        'classes_feature_2_desc' => 'Acompanhe membros, mensalidades, instrutores, pacotes e presencas.',
        'classes_feature_3' => 'Espacos, salas e capacidade',
        'classes_feature_3_desc' => 'Associe aulas a salas, locais e limites de vagas.',
        'classes_feature_4' => 'Reservas online e lista de espera',
        'classes_feature_4_desc' => 'Permita inscricoes em aulas e pedidos em lista de espera.',
        'classes_feature_5' => 'Relatorios e acompanhamento operacional',
        'classes_feature_5_desc' => 'Consulte receitas, mensalidades, presencas e desempenho dos treinadores.',
        'hotel_plan_name' => 'Hotel Housekeeping',
        'hotel_plan_desc' => 'Operacoes de limpeza para equipas de alojamento.',
        'hotel_contact_title' => 'Plano ajustado a sua operacao',
        'hotel_contact_desc' => 'Fale connosco para definir o plano certo.',
        'hotel_feature_1' => 'Quartos, pisos e estados de limpeza',
        'hotel_feature_2' => 'Atribuicao de tarefas por equipa',
        'hotel_feature_3' => 'Checklist e progresso em tempo real',
        'hotel_feature_4' => 'Operacao responsiva para equipas no terreno',
        'contact_sales' => 'Contactar',
        'start_now' => 'Comecar agora',
    ],
    'en' => [
        'category_eyebrow' => 'Choose your business area',
        'category_title' => 'Plans by operation type',
        'category_intro' => 'See the right plan for your active business area.',
        'bookings_title' => 'Bookings',
        'bookings_desc' => 'For businesses that manage appointments, clients and professionals.',
        'bookings_examples' => 'Salons, clinics, therapists and other appointment-based services.',
        'classes_title' => 'Classes & Spaces',
        'classes_desc' => 'For studios, gyms and academies that manage classes, members and instructors.',
        'classes_examples' => 'Pilates, yoga, CrossFit, martial arts, dance, swimming, padel and fitness.',
        'hotel_title' => 'Hotel Housekeeping',
        'hotel_desc' => 'For accommodation businesses that manage rooms, teams and housekeeping operations.',
        'hotel_examples' => 'Hotels, hostels, resorts and guest houses.',
        'billing' => 'Billing',
        'monthly' => 'Monthly',
        'annual' => 'Annual',
        'save_10' => 'Save 10%',
        'per_month_short' => '/ month',
        'per_year_short' => '/ year',
        'classes_plan_name' => 'Classes & Spaces',
        'classes_plan_desc' => 'One plan to manage classes, members, instructors and spaces clearly.',
        'classes_feature_1' => 'Class and schedule management',
        'classes_feature_1_desc' => 'Create classes, categories and recurring schedules to organize the calendar.',
        'classes_feature_2' => 'Members, instructors and attendance',
        'classes_feature_2_desc' => 'Track members, memberships, instructors, packages and attendance records.',
        'classes_feature_3' => 'Spaces, rooms and capacity',
        'classes_feature_3_desc' => 'Connect classes to rooms, locations and capacity limits.',
        'classes_feature_4' => 'Online bookings and waitlist',
        'classes_feature_4_desc' => 'Let members book classes and join waiting lists.',
        'classes_feature_5' => 'Reports and operational tracking',
        'classes_feature_5_desc' => 'Review revenue, membership, attendance and coach performance reports.',
        'hotel_plan_name' => 'Hotel Housekeeping',
        'hotel_plan_desc' => 'Cleaning operations for accommodation teams.',
        'hotel_contact_title' => 'A plan adjusted to your operation',
        'hotel_contact_desc' => 'Talk to us to define the right plan.',
        'hotel_feature_1' => 'Rooms, floors and cleaning states',
        'hotel_feature_2' => 'Task assignment by team',
        'hotel_feature_3' => 'Checklist and real-time progress',
        'hotel_feature_4' => 'Responsive operation for field teams',
        'contact_sales' => 'Contact us',
        'start_now' => 'Start now',
    ],
];

$t = static function ($key) use ($pricingText, $currentLanguage) {
    $translated = Yii::t('app', 'pricing_' . $key);

    if ($translated !== 'pricing_' . $key) {
        return $translated;
    }

    return $pricingText[$currentLanguage][$key] ?? $pricingText['en'][$key] ?? $key;
};

$classesQuote = MyPlanPricingHelper::quote();
$classesMonthlyPrice = $classesQuote['monthly'];
$classesAnnualPrice = $classesQuote['annual'];
$myPlanPaymentPlan = 'gym';
$myPlanPaymentCoin = strtolower($classesQuote['currency']);
$classesMonthlyPaymentUrl = [
    '/my-plan/payment',
    'coin' => $myPlanPaymentCoin,
    'plan' => $myPlanPaymentPlan,
    'period' => 'month',
    'locations' => $locations,
    'professionals' => $professionals,
];
$classesAnnualPaymentUrl = [
    '/my-plan/payment',
    'coin' => $myPlanPaymentCoin,
    'plan' => $myPlanPaymentPlan,
    'period' => 'year',
    'locations' => $locations,
    'professionals' => $professionals,
];
$formatPlanPrice = static function ($value) use ($classesQuote) {
    return Helpers::formatCurrency($value, $classesQuote['currency']);
};
$categories = [
    'classes-spaces' => ['icon' => 'bx bx-dumbbell', 'title' => $t('classes_title'), 'desc' => $t('classes_desc'), 'examples' => $t('classes_examples')],
    'bookings' => ['icon' => 'bx bx-calendar-check', 'title' => $t('bookings_title'), 'desc' => $t('bookings_desc'), 'examples' => $t('bookings_examples')],
    'hotel-housekeeping' => ['icon' => 'bx bx-hotel', 'title' => $t('hotel_title'), 'desc' => $t('hotel_desc'), 'examples' => $t('hotel_examples')],
];
$visiblePricingCategories = array_filter($categories, static function ($categoryKey) use ($pricingCategoriesVisibility) {
    return !empty($pricingCategoriesVisibility[$categoryKey]);
}, ARRAY_FILTER_USE_KEY);
?>
<style>
    .payments-index > .my-plan-surface {
        box-sizing: border-box;
        width: 100%;
        margin-inline: 0;
        background: #fff;
        border: 1px solid #e8edf5 !important;
        border-radius: 20px !important;
        box-shadow: 0 4px 18px rgba(15, 23, 42, .035) !important;
    }
    .plan-actual {
        border: 5px solid #b6ff00;
    }

    .my-plan-pricing-intro {
        max-width: 760px;
    }

    .my-plan-category-grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .my-plan-category-card {
        align-items: flex-start;
        background: #fff;
        border: 1px solid #e8edf5;
        border-radius: 18px;
        box-shadow: 0 12px 30px rgba(15, 23, 42, .05);
        color: #111827;
        display: flex;
        gap: .9rem;
        min-height: 154px;
        padding: 1.2rem;
        text-decoration: none;
    }

    .my-plan-category-card:hover,
    .my-plan-category-card.active {
        border-color: var(--sc-primary, #0d6efd);
        color: #111827;
        text-decoration: none;
    }

    .my-plan-category-icon {
        align-items: center;
        background: rgba(var(--sc-primary-rgb, 13, 110, 253), .1);
        border-radius: 14px;
        color: var(--sc-primary, #0d6efd);
        display: inline-flex;
        flex: 0 0 46px;
        font-size: 24px;
        height: 46px;
        justify-content: center;
        width: 46px;
    }

    .my-plan-category-card.active .my-plan-category-icon {
        background: var(--sc-primary, #0d6efd);
        color: #fff;
    }

    .my-plan-section-panel {
        background: #f8fafc;
        border: 1px solid #edf1f7;
        border-radius: 24px;
        padding: 1.4rem;
    }

    .my-plan-single-plan {
        display: grid;
        gap: 1.5rem;
        grid-template-columns: minmax(0, .95fr) minmax(0, 1.05fr);
    }

    .my-plan-single-card {
        background: #fff;
        border: 1px solid #e8edf5;
        border-radius: 22px;
        box-shadow: 0 16px 34px rgba(15, 23, 42, .06);
        padding: 1.5rem;
    }

    .billing-segment {
        background: #f1f5f9;
        border-radius: 999px;
        display: inline-flex;
        gap: .35rem;
        padding: .35rem;
    }

    .billing-option {
        background: transparent;
        border: 0;
        border-radius: 999px;
        color: #475467;
        cursor: pointer;
        font-weight: 800;
        padding: .7rem 1rem;
    }

    .billing-option.active {
        background: #fff;
        box-shadow: 0 6px 18px rgba(15, 23, 42, .08);
        color: #111827;
    }

    .billing-save {
        background: #d9f99d;
        border-radius: 999px;
        color: #365314;
        font-size: .75rem;
        margin-left: .4rem;
        padding: .2rem .45rem;
    }

    .single-plan-price strong {
        color: #111827;
        font-size: 2.35rem;
        line-height: 1;
    }

    .pricing-feature-list {
        list-style: none;
        margin: 1.2rem 0 0;
        padding: 0;
    }

    .pricing-feature-list li {
        margin-bottom: .75rem;
        padding-left: 1.9rem;
        position: relative;
    }

    .pricing-feature-list li:before {
        align-items: center;
        background: #dcfce7;
        border-radius: 999px;
        color: #16803c;
        content: "\2713";
        display: inline-flex;
        font-size: .75rem;
        font-weight: 900;
        height: 20px;
        justify-content: center;
        left: 0;
        position: absolute;
        top: .05rem;
        width: 20px;
    }

    @media (max-width: 991.98px) {
        .my-plan-category-grid,
        .my-plan-single-plan {
            grid-template-columns: 1fr;
        }
    }
    .payments-index > .my-plan-surface.my-plan-custom-app {
        background: radial-gradient(ellipse at 12% 0%, rgba(20, 184, 166, .28), transparent 55%), radial-gradient(ellipse at 90% 100%, rgba(139, 92, 246, .3), transparent 60%), #101b30;
        border-color: #26394e !important;
        box-shadow: 0 12px 30px rgba(16, 27, 48, .14) !important;
        color: #fff;
    }
    .my-plan-custom-layout { display: grid; grid-template-columns: 52px minmax(0, 1fr) minmax(210px, 260px); align-items: center; gap: 1.25rem; }
    .my-plan-custom-icon { display: flex; align-items: center; justify-content: center; height: 52px; border-radius: 16px; background: linear-gradient(145deg, #5eead4, #38bdf8); color: #102a43; box-shadow: 0 8px 20px rgba(45, 212, 191, .18); align-self: start; }
    .my-plan-custom-copy { min-width: 0; }
    .my-plan-custom-eyebrow { display: inline-flex; align-items: center; gap: .4rem; color: #99f6e4; font-size: .72rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; margin-bottom: .65rem; }
    .my-plan-custom-copy h2 { line-height: 1.3; color: #fff; font-size: clamp(1.2rem, 2vw, 1.65rem); }
    .my-plan-custom-app .text-muted { color: #c0cee0 !important; }
    .my-plan-custom-copy p { max-width: 48ch; line-height: 1.6; }
    .my-plan-custom-price { text-align: right; background: rgba(0, 0, 0, .16); border: 1px solid rgba(255, 255, 255, .13); border-radius: 16px; padding: 1rem; }
    .my-plan-custom-amount strong { color: #fff; font-size: 2rem; letter-spacing: -.04em; }
    .my-plan-custom-amount { justify-content: flex-end; }
    .my-plan-custom-app a.my-plan-custom-contact { width: 100%; min-height: 44px; height: auto; display: inline-flex; align-items: center; justify-content: center; gap: .5rem; background: #bef264 !important; color: #19320d !important; border: 0; font-weight: 700; box-shadow: 0 5px 16px rgba(190, 242, 100, .15); }
    .my-plan-custom-app a.my-plan-custom-contact:hover { background: #d9f99d !important; transform: translateY(-1px); }
    .my-plan-custom-app a.my-plan-custom-contact:focus-visible { outline: 3px solid #fff; outline-offset: 3px; }
    @media (max-width: 991.98px) {
        .my-plan-custom-layout { grid-template-columns: 40px minmax(0, 1fr); align-items: start; gap: .85rem; }
        .my-plan-custom-icon { height: 40px; border-radius: 12px; }
        .my-plan-custom-price { grid-column: 1 / -1; text-align: left; }
        .my-plan-custom-amount { justify-content: flex-start; }
        .my-plan-custom-contact { width: 100%; }
    }


    @media (max-width: 767.98px) {
        .my-plan-single-card { padding: 1rem; border-radius: 16px; }
        .my-plan-section-panel {
            background: transparent;
            border: 0;
            border-radius: 0;
            padding: 0;
        }
    }
</style>

<div class="payments-index">
    <?= Helpers::displayAminBreadcrumbs('settings', 'my_plan', ['my-plan']) ?>

    <div class="client-search-box border rounded-4 p-3 p-lg-4 mb-4 my-plan-surface">
        <div class="my-plan-pricing-intro mb-4">
            <div class="text-primary fw-bold text-uppercase small mb-1"><?= Html::encode(Yii::t('app', 'my_plan')) ?></div>
            <h2 class="h3 fw-bold mb-2"><?= Html::encode($categories[$selectedCategory]['title']) ?></h2>
            <p class="text-muted mb-0"><?= Html::encode($categories[$selectedCategory]['desc']) ?></p>
        </div>

        <?php if (count($visiblePricingCategories) > 1): ?>
            <div class="my-plan-category-grid mb-4">
                <?php foreach ($visiblePricingCategories as $categoryKey => $category): ?>
                    <a class="my-plan-category-card <?= $selectedCategory === $categoryKey ? 'active' : '' ?>" href="<?= Url::to(['/my-plan', 'category' => $categoryKey]) ?>">
                        <span class="my-plan-category-icon"><i class="<?= Html::encode($category['icon']) ?>"></i></span>
                        <span>
                            <span class="d-block fw-bold mb-1"><?= Html::encode($category['title']) ?></span>
                            <span class="d-block text-muted small mb-2"><?= Html::encode($category['desc']) ?></span>
                            <span class="d-block text-muted small"><?= Html::encode($category['examples']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($selectedCategory === 'bookings'): ?>
            <div class="row">
                <div class="col-lg-3 mb-3">
                    <div class="input-group-modern">
                        <i class="bx bx-euro"></i>
                        <select id="price-subscription" class="form-control form-select-modern" onchange="setPricing();" data-percentage="0.25">
                            <?php foreach ($typeArr as $value): ?>
                                <option value="<?= $value ?>"><?= Yii::t('app', 'pricing_' . $value) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-12 d-none">
                    <select id="price-currency" class="form-control text-3 h-auto py-2" data-language="<?= strtolower(Yii::$app->language) ?>" onchange="setPricing();">
                        <?php foreach (Helpers::arrayPricing() as $value): ?>
                            <option value="<?= $value['key'] ?>" data-coin="<?= $value['coin'] ?>" data-basic="<?= $value['basic'] ?>" data-standard="<?= $value['standard'] ?>" data-professional="<?= $value['professional'] ?>" data-enterprise="<?= $value['enterprise'] ?>">
                                <?= Yii::t('app', $value['page_code_title']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div id="price-table">
                <?= $this->render('/site/pricing/price', [
                    'arrPricing' => $arrPricing,
                    'professionalsPrice' => $professionalsPrice,
                    'locationsPrice' => $locationsPrice,
                    'locations' => $locations,
                    'professionals' => $professionals,
                ]) ?>
            </div>
        <?php elseif ($selectedCategory === 'classes-spaces'): ?>
            <div class="my-plan-section-panel">
                <div class="my-plan-single-plan">
                    <div class="my-plan-single-card">
                        <h2 class="h4 fw-bold my-plan-feature-title"><?= Html::encode($t('classes_plan_name')) ?></h2>
                        <p class="text-muted"><?= Html::encode($t('classes_plan_desc')) ?></p>
                        <ul class="pricing-feature-list">
                            <li><strong><?= Html::encode($t('classes_feature_1')) ?></strong><span class="d-block text-muted small"><?= Html::encode($t('classes_feature_1_desc')) ?></span></li>
                            <li><strong><?= Html::encode($t('classes_feature_2')) ?></strong><span class="d-block text-muted small"><?= Html::encode($t('classes_feature_2_desc')) ?></span></li>
                            <li><strong><?= Html::encode($t('classes_feature_3')) ?></strong><span class="d-block text-muted small"><?= Html::encode($t('classes_feature_3_desc')) ?></span></li>
                            <li><strong><?= Html::encode($t('classes_feature_4')) ?></strong><span class="d-block text-muted small"><?= Html::encode($t('classes_feature_4_desc')) ?></span></li>
                            <li><strong><?= Html::encode($t('classes_feature_5')) ?></strong><span class="d-block text-muted small"><?= Html::encode($t('classes_feature_5_desc')) ?></span></li>
                        </ul>
                    </div>
                    <div class="my-plan-single-card">
                        <label class="d-block fw-bold mb-2"><?= Html::encode($t('billing')) ?></label>
                        <div class="billing-segment" role="group" aria-label="<?= Html::encode($t('billing')) ?>">
                            <button type="button" class="billing-option active" data-classes-billing="monthly"><?= Html::encode($t('monthly')) ?></button>
                            <button type="button" class="billing-option" data-classes-billing="annual">
                                <?= Html::encode($t('annual')) ?>
                                <span class="billing-save"><?= Html::encode($t('save_10')) ?></span>
                            </button>
                        </div>
                        <div class="single-plan-price d-flex align-items-baseline gap-2 my-4">
                            <strong id="classes-spaces-price"><?= Html::encode($formatPlanPrice($classesMonthlyPrice)) ?></strong>
                            <span id="classes-spaces-period" class="text-muted fw-bold"><?= Html::encode($t('per_month_short')) ?></span>
                        </div>
                        <?php if ($classesQuote['fallback']): ?>
                            <p class="small text-muted"><?= Html::encode(Yii::t('app', 'plan_currency_unavailable')) ?></p>
                        <?php elseif ($classesQuote['rateDate']): ?>
                            <p class="small text-muted"><?= Html::encode(Yii::t('app', 'plan_currency_rate_date', ['date' => Yii::$app->formatter->asDate($classesQuote['rateDate'])])) ?></p>
                        <?php endif; ?>
                        <div class="text-muted small mt-2 mb-3">
                            <?= Html::encode(Yii::t('app', 'pricing_iva_added_23_percent')) ?>
                        </div>
                        <?= Html::a(Html::encode($t('start_now')), $classesMonthlyPaymentUrl, ['id' => 'classes-spaces-payment-link', 'class' => 'btn btn-primary-modern rounded-4 w-100']) ?>
                    </div>
                </div>
            </div>
            <?php
            $monthlyPriceJson = json_encode($formatPlanPrice($classesMonthlyPrice));
            $annualPriceJson = json_encode($formatPlanPrice($classesAnnualPrice));
            $monthLabelJson = json_encode($t('per_month_short'));
            $yearLabelJson = json_encode($t('per_year_short'));
            $monthlyPaymentUrlJson = json_encode(Url::to($classesMonthlyPaymentUrl));
            $annualPaymentUrlJson = json_encode(Url::to($classesAnnualPaymentUrl));
            $this->registerJs(<<<JS
(function () {
    var monthlyPrice = {$monthlyPriceJson};
    var annualPrice = {$annualPriceJson};
    var monthLabel = {$monthLabelJson};
    var yearLabel = {$yearLabelJson};
    var monthlyPaymentUrl = {$monthlyPaymentUrlJson};
    var annualPaymentUrl = {$annualPaymentUrlJson};
    var price = document.getElementById('classes-spaces-price');
    var period = document.getElementById('classes-spaces-period');
    var paymentLink = document.getElementById('classes-spaces-payment-link');
    document.querySelectorAll('[data-classes-billing]').forEach(function (button) {
        button.addEventListener('click', function () {
            document.querySelectorAll('[data-classes-billing]').forEach(function (item) {
                item.classList.remove('active');
            });
            button.classList.add('active');
            var isAnnual = button.getAttribute('data-classes-billing') === 'annual';
            price.textContent = isAnnual ? annualPrice : monthlyPrice;
            period.textContent = isAnnual ? yearLabel : monthLabel;
            if (paymentLink) {
                paymentLink.href = isAnnual ? annualPaymentUrl : monthlyPaymentUrl;
            }
        });
    });
})();
JS); ?>
        <?php else: ?>
            <div class="my-plan-section-panel">
                <div class="my-plan-single-plan">
                    <div class="my-plan-single-card">
                        <h2 class="h4 fw-bold"><?= Html::encode($t('hotel_plan_name')) ?></h2>
                        <p class="text-muted"><?= Html::encode($t('hotel_plan_desc')) ?></p>
                        <ul class="pricing-feature-list">
                            <li><?= Html::encode($t('hotel_feature_1')) ?></li>
                            <li><?= Html::encode($t('hotel_feature_2')) ?></li>
                            <li><?= Html::encode($t('hotel_feature_3')) ?></li>
                            <li><?= Html::encode($t('hotel_feature_4')) ?></li>
                        </ul>
                    </div>
                    <div class="my-plan-single-card">
                        <h2 class="h4 fw-bold"><?= Html::encode($t('hotel_contact_title')) ?></h2>
                        <p class="text-muted"><?= Html::encode($t('hotel_contact_desc')) ?></p>
                        <?= Html::a(Html::encode($t('contact_sales')), 'https://wa.me/351939645894', ['class' => 'btn btn-dark w-100 py-3 mt-3', 'target' => '_blank', 'aria-label' => 'Chat on WhatsApp']) ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <section class="border rounded-4 mb-4 client-search-box p-3 p-lg-4 my-plan-surface my-plan-custom-app">
            <div class="my-plan-custom-layout">
                    <div class="my-plan-custom-icon">
                        <i class="bx bx-mobile-alt fs-2" aria-hidden="true"></i>
                    </div>
                <div class="my-plan-custom-copy">
                    <div class="my-plan-custom-eyebrow"><i class="bx bx-star" aria-hidden="true"></i><?= Html::encode(Yii::t('app', 'custom_company_app_eyebrow')) ?></div>
                    <h2 class="h4 fw-bold mb-2"><?= Html::encode(Yii::t('app', 'custom_company_app_title')) ?></h2>
                    <p class="text-muted mb-0"><?= Html::encode(Yii::t('app', 'custom_company_app_description')) ?></p>
                </div>
                <div class="my-plan-custom-price">
                    <div class="d-flex flex-wrap align-items-baseline gap-2 my-plan-custom-amount mb-1">
                        <strong class="h2 fw-bold mb-0"><?= Html::encode($formatPlanPrice($classesQuote['customApp'])) ?></strong>
                        <span class="text-muted fw-semibold"><?= Html::encode(Yii::t('app', 'custom_company_app_vat')) ?></span>
                    </div>
                    <div class="text-muted small mb-3"><?= Html::encode(Yii::t('app', 'custom_company_app_one_time')) ?></div>
                    <?php if ($classesQuote['fallback']): ?>
                        <p class="small text-muted"><?= Html::encode(Yii::t('app', 'plan_currency_unavailable')) ?></p>
                    <?php elseif ($classesQuote['rateDate']): ?>
                        <p class="small text-muted"><?= Html::encode(Yii::t('app', 'plan_currency_rate_date', ['date' => Yii::$app->formatter->asDate($classesQuote['rateDate'])])) ?></p>
                    <?php endif; ?>
                    <?= Html::a(Html::encode(Yii::t('app', 'custom_company_app_cta')) . '<i class="bx bx-right-arrow-alt" aria-hidden="true"></i>', 'https://wa.me/351939645894', ['class' => 'btn rounded-4 px-3 my-plan-custom-contact', 'target' => '_blank', 'rel' => 'noopener noreferrer']) ?>
                </div>
            </div>
    </section>

    <div class="row">
        <?php foreach ($arrProgressbars as $key => $value): ?>
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <h4 class="card-title"><?= Yii::t('app', $key) ?></h4>
                            </div>
                            <div class="col-6 text-right">
                                <?= Html::a(Yii::t('app', 'add_credit'), $value['url'], ['class' => 'btn btn-outline-primary mr-2']) ?>
                            </div>
                        </div>

                        <div class="text-2 pt-2">
                            <span class="p-1">
                                <?= Yii::t('app', 'credit') ?> : <?= $value['used'] ?>/<?= $value['total'] ?>
                            </span>
                            <div class="progress animated-progess mt-1">
                                <div class="progress-bar <?= Helpers::progressBarColor($value['percentage']) ?> progress-bar-striped" role="progressbar" style="width: <?= $value['percentage'] ?>%;" aria-valuenow="<?= $value['used'] ?>" aria-valuemin="0" aria-valuemax="<?= $value['total'] ?>"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?= $this->render('balance') ?>

    <?= $this->render('packages') ?>
</div>
