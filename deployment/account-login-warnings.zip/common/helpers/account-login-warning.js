(function () {
  if (window.__scLoginWarningInstalled) return;
  window.__scLoginWarningInstalled = true;
  let seen = '', busy = false;
  async function acknowledge(token) {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content;
    if (!csrf) return;
    await fetch('/account-login-warning/acknowledge', {method:'POST',credentials:'same-origin',
      headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF-Token':csrf},
      body:new URLSearchParams({token}).toString()});
  }
  async function check() {
    if (busy || document.hidden) return;
    busy = true;
    try {
      const response = await fetch('/account-login-warning/status', {credentials:'same-origin',cache:'no-store',headers:{'X-Requested-With':'XMLHttpRequest'}});
      if (!response.ok) return;
      const result = await response.json(), warning = result.data?.warning;
      if (!warning || warning.token === seen) return;
      seen = warning.token;
      if (window.ReactNativeWebView) {
        window.ReactNativeWebView.postMessage(JSON.stringify({type:'sc.account.login-warning',documentUrl:location.href,...warning}));
      } else {
        window.alert(warning.title + '\n\n' + warning.message);
        await acknowledge(warning.token);
      }
    } catch (error) { /* Keep login and the current screen usable when offline. */ }
    finally { busy = false; }
  }
  window.__scAcknowledgeLoginWarning = acknowledge;
  check();
  let interval = setInterval(check, 30000);
  document.addEventListener('visibilitychange', check);
  window.addEventListener('pageshow', () => { clearInterval(interval);interval=setInterval(check,30000);check(); });
  window.addEventListener('pagehide', () => clearInterval(interval));
})();
